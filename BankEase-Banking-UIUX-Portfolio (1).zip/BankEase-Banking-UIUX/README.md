# BankEase — Banking Application UI/UX Portfolio

A responsive, interactive banking dashboard concept created to demonstrate UI/UX fundamentals, visual design, navigation, responsive layouts and micro-interactions.

> **Portfolio disclaimer:** BankEase is a fictional educational design concept. It is not connected to a real bank. All names, account details and transaction values are sample data. The transfer form does not move money, and the login is a visual concept only.

## Live demo
After enabling GitHub Pages, add your published URL here.

## Figma design
Add your Figma file / prototype URL here.

## Project goals
- Present financial information with clear visual hierarchy.
- Make common tasks easy to discover.
- Use consistent colours, typography, spacing and components.
- Demonstrate responsive behaviour on desktop and mobile.
- Add purposeful animations and feedback without distracting users.

## Screens and interactions
1. Overview dashboard — balance, income, expenses, cash-flow chart and recent transactions.
2. Transactions — searchable sample transaction list and CSV export.
3. My cards — sample card details and freeze/unfreeze demo interaction.
4. Analytics — sample financial summary and illustration.
5. Profile — fictional user details.
6. Settings — interactive preference toggles.
7. Transfer dialog — form validation and confirmation feedback (no real transfer).

## UX decisions
- Persistent left navigation on desktop; collapsible navigation on smaller screens.
- Blue is used as the primary action colour; green and red distinguish positive and negative amounts.
- Labels accompany colour/status indicators so colour is not the only signal.
- Forms have visible labels, focus states and basic validation.
- Reduced-motion preference is respected through `prefers-reduced-motion`.
- Demo interactions clearly explain that no real banking action occurs.

## Visual system
- Primary navy: `#173B67`
- Primary blue: `#2878D0`
- Page background: `#F6F8FB`
- Success: `#16A477`
- Typography: DM Sans and Manrope
- Layout: responsive CSS Grid and Flexbox

## Animations
- Page transitions
- Animated chart bars
- Donut chart entrance
- Subtle floating payment card
- Button hover and toast feedback
- Reduced-motion media query

## Tech stack
HTML5 · CSS3 · Vanilla JavaScript · SVG assets · GitHub Pages

## Run locally
1. Download or clone this repository.
2. Open `index.html` in a browser.
3. For a local development server, use VS Code Live Server.

No build tools or package installation are required.

## Repository structure
```text
BankEase-Banking-UIUX/
├── index.html
├── styles.css
├── script.js
├── assets/
│   ├── avatar.svg
│   └── analytics.svg
├── screenshots/
└── README.md
```

## Publish with GitHub Pages
1. Push the project to a public GitHub repository.
2. Open **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select `main` and `/ (root)`, then Save.
5. Wait for GitHub Pages to publish the site. Add the URL to this README.

## Suggested next improvements
- Create a matching Figma file with desktop and mobile frames.
- Add a clickable Figma prototype for Login → Overview → Transfer → Confirmation.
- Conduct 3–5 informal usability tests and record improvements.
- Add keyboard focus testing and contrast checks.
- Replace all sample content only with clearly labelled fictional data.

## Author
Add your name and portfolio links here.
