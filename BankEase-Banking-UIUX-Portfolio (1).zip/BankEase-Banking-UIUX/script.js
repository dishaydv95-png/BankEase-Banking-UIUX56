const toast = document.getElementById("toast");
let toastTimer;
function showToast(message){
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(()=>toast.classList.remove("show"),2600);
}

const views = ["overview","transactions","cards","analytics","profile","settings"];
function showView(view){
  views.forEach(name=>{
    document.getElementById(name+"View").classList.toggle("active-view",name===view);
  });
  document.querySelectorAll(".nav-link").forEach(btn=>btn.classList.toggle("active",btn.dataset.view===view));
  document.getElementById("pageCrumb").textContent = view.charAt(0).toUpperCase()+view.slice(1);
  document.getElementById("sidebar").classList.remove("open");
  window.scrollTo({top:0,behavior:"smooth"});
}
document.querySelectorAll(".nav-link").forEach(btn=>btn.addEventListener("click",()=>showView(btn.dataset.view)));
document.querySelectorAll("[data-go]").forEach(btn=>btn.addEventListener("click",()=>showView(btn.dataset.go)));
document.getElementById("mobileMenu").addEventListener("click",()=>document.getElementById("sidebar").classList.toggle("open"));
document.getElementById("profileShortcut").addEventListener("click",()=>showView("profile"));
document.getElementById("quickTransfer").addEventListener("click",()=>document.getElementById("transferDialog").showModal());
document.getElementById("helpButton").addEventListener("click",()=>showToast("Help centre is a demo interaction."));
document.getElementById("notificationButton").addEventListener("click",()=>showToast("You’re all caught up!"));
document.getElementById("logoutButton").addEventListener("click",()=>showToast("This is a portfolio demo — no account was logged out."));
document.getElementById("addCardButton").addEventListener("click",()=>showToast("Card management is a visual demo."));
document.getElementById("freezeButton").addEventListener("click",e=>{
  e.currentTarget.textContent = e.currentTarget.textContent.includes("Freeze") ? "Unfreeze demo card" : "Freeze demo card";
  showToast("Demo card status changed.");
});
document.getElementById("periodSelect").addEventListener("change",e=>showToast("Chart period: "+e.target.value));

const transferDialog = document.getElementById("transferDialog");
document.getElementById("transferForm").addEventListener("submit",e=>{
  e.preventDefault();
  const data = new FormData(e.currentTarget);
  const amount = Number(data.get("amount"));
  if(amount>50000){showToast("For this demo, the maximum is ₹50,000.");return;}
  transferDialog.close();
  e.currentTarget.reset();
  showToast(`Demo transfer of ₹${amount.toLocaleString("en-IN")} prepared. No money was sent.`);
});

const sampleTransactions = [
  {name:"Spotify Premium",desc:"Subscription",date:"19 Nov 2026",type:"Expense",amount:-119,status:"Completed",icon:"S",tone:"purple"},
  {name:"Neha Sharma",desc:"Money received",date:"18 Nov 2026",type:"Income",amount:2500,status:"Completed",icon:"N",tone:"blue"},
  {name:"Amazon India",desc:"Shopping",date:"17 Nov 2026",type:"Expense",amount:-1249,status:"Pending",icon:"A",tone:"orange"},
  {name:"Monthly salary",desc:"Salary credit",date:"15 Nov 2026",type:"Income",amount:35000,status:"Completed",icon:"W",tone:"green"},
  {name:"Metro recharge",desc:"Transport",date:"13 Nov 2026",type:"Expense",amount:-650,status:"Completed",icon:"M",tone:"blue"},
  {name:"Riya Verma",desc:"Rent share",date:"11 Nov 2026",type:"Income",amount:8500,status:"Completed",icon:"R",tone:"purple"}
];
function money(value){return (value<0?"− ":"+ ")+"₹"+Math.abs(value).toLocaleString("en-IN",{minimumFractionDigits:2,maximumFractionDigits:2});}
function renderTransactions(rows,target){
  target.innerHTML = rows.map(t=>`<tr><td><span class="transaction-person"><b class="merchant-icon ${t.tone}">${t.icon}</b><span><strong>${t.name}</strong><small>${t.desc}</small></span></span></td><td>${t.date}</td><td>${t.type}</td><td class="${t.amount<0?"amount-out":"amount-in"}">${money(t.amount)}</td><td><span class="status-badge ${t.status==="Completed"?"success":"pending"}">${t.status}</span></td></tr>`).join("");
}
const allRows = document.getElementById("allTransactionRows");
renderTransactions(sampleTransactions,allRows);
document.getElementById("transactionSearch").addEventListener("input",e=>{
  const q=e.target.value.toLowerCase();
  renderTransactions(sampleTransactions.filter(t=>(t.name+" "+t.desc+" "+t.type+" "+t.status).toLowerCase().includes(q)),allRows);
});
document.getElementById("exportButton").addEventListener("click",()=>{
  const csv=["Name,Description,Date,Type,Amount,Status",...sampleTransactions.map(t=>[t.name,t.desc,t.date,t.type,t.amount,t.status].map(v=>`"${String(v).replaceAll('"','""')}"`).join(","))].join("\n");
  const blob=new Blob([csv],{type:"text/csv"});
  const url=URL.createObjectURL(blob);
  const a=document.createElement("a");a.href=url;a.download="bankease-demo-transactions.csv";a.click();URL.revokeObjectURL(url);
  showToast("Sample transaction CSV downloaded.");
});
document.querySelectorAll(".toggle-switch").forEach(btn=>btn.addEventListener("click",()=>{
  const on=btn.classList.toggle("on");btn.setAttribute("aria-pressed",String(on));
  if(btn.id==="balanceToggle"){
    document.getElementById("balanceAmount").innerHTML=on?'₹1,24,850<span>.00</span>':"••••••••";
  }
  if(btn.id==="motionToggle")document.body.classList.toggle("reduce-motion-demo",on);
  showToast(on?"Preference enabled.":"Preference disabled.");
}));
